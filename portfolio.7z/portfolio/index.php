<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
    <link rel="stylesheet" href="css\all.css">
    <link rel="stylesheet" href="css\animate.min.css">
    <script src = "js\jquery.min.js"></script>
    <script src = "js\popper.min.js"></script>
    <script src = "js\bootstrap.min.js"></script>
    <script src = "js\myown.js"></script>
    <title>Portfolio</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <a class="navbar-brand" href="#">Rejwan Portfolio <span><img src="images/logo.png" width = "6%;"alt=""></span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Home <span><i class="fas fa-home"></i></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#about_me">About Me <span><i class="fas fa-address-card"></i></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#skills">Skills <span><i class="fas fa-cogs"></i></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#projects">Projects <span><i class="fas fa-tasks"></i></span></a>
                </li>
            </ul>
        </div>
    </nav>
    <!--Start of Second Part -->
    <div class="wrapper animate__animated animate__backInLeft">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-12 second_part">
                    <h1>Hi,</h1>
                    <h3>I am Rejwan Ahmed</h3>
                    <h4>A Full Stack Web Developer</h4>
                    <button type = "button" onclick = "myfunction()"class = " mt-3 btn contact_me_btn">Contact Me</button>
                    <h6 id = "contact_me_details" class = "mt-3  "></h6>
                </div>
                <div class="col-lg-7 col-md-12 col-12 text-center">
                    <img src="images/rejwan.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!--End of Second Part -->

    <!--Start of Third Part -->
    <div class="container mt-5 animate__animated animate__bounceInRight" id = "about_me">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 col-12">
                <div class="card">
                    <div class="third_part_header">
                        <h3 class = "text-center"><b>About Me</b></h3>
                    </div>
                    <div class="card-body">
                        <p class = "text-justify font-italic">Hi, this is Md. Rejwan Ahmed. I have completed my B.Sc. in Computer Science & Engineering from Jatiya Kabi Kazi Nazrul Islam University. I hvae ability to work with PHP, Javascript, C++. I can work well under pressure and make the best of any situation. I am passionate about learning new things.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End of Third Part -->

    <!-- Start of Skills -->
    <div class="container mt-5 animate__animated animate__flipInX" id = "skills">
        <div class="text-center">
            <h3><b>Skills</b></h3>
            <p>Following skills i acquired during my university life</p>
        </div>

        <div class="row justify-content-center text-center skill_body">
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "htmlinfunction()" onmouseout = "htmloutfunction()">
                <img class = "m-4" src="images/html.png" width = "100" height = "100"alt="" >
                <div id="html">

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "cssinfunction()" onmouseout = "cssoutfunction()">
                <img class = "m-4" src="images/css.png" width = "100" height = "100"alt="">
                <div id="css">

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "bootstrapinfunction()" onmouseout = "bootstrapoutfunction()">
                <img class = "m-4" src="images/bootstrap.png" width = "100" height = "100"alt="">
                <div id="bootstrap">

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "jsinfunction()" onmouseout = "jsoutfunction()">
                <img class = "m-4" src="images/js.png" width = "100" height = "100"alt="">
                <div id="js">

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "phpinfunction()" onmouseout = "phpoutfunction()">
                <img class = "m-4" src="images/php.png" width = "100" height = "100"alt="">
                <div id="php">

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-12 shadow-lg m-4 p-2" onmouseover = "laravelinfunction()" onmouseout = "laraveloutfunction()">
                <img class = "m-4" src="images/laravel.png" width = "100" height = "100"alt="">
                <div id="laravel">

                </div>
            </div>
        </div>
    </div>
    <!-- End of Skills -->

    <!-- Start of Projects -->
    <div class="container mt-5 animate__animated animate__fadeInUp" id = "projects">
        <div class="text-center">
            <h3><b>Projects</b></h3>
            <p>My Completed Projects</p>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="project_header mb-3">
                    <h5>Project Name: Project Book</h5>
                </div>
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100 h-100" src="images/01.png" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100 h-100" src="images/02.png" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100 h-100" src="images/03.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100 h-100" src="images/04.png" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100 h-100" src="images/05.png" alt="Third slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
                <div class="project_header mt-3">
                    <h5>Github Link: <a href=""></a></h5>
                    <h5>Server Link: <a href=""></a></h5>
                </div>
            </div>
        </div>
    </div>
    <!-- End of Projects -->

    <!-- Start of Footer -->
    <footer class = "mt-5 animate__animated animate__bounceInLeft">
        <div class="container-fluid">
            <div class="row footer">
                <div class="col-lg-6 col-md-4 col-12 text-center">
                    <img src="images/logo.png" width = "20%" height = "100px" alt="">
                    <h4 class = "text-center mt-4">This is my own built personal website</h4>
                </div>
                <div class="col-lg-3 col-md-4 col-12 quick_links">
                    <h5><b>Quick Links</b></h5>
                    <p><a class="nav-link" href="#"><span><i class="fas fa-home"></i></span> Home</a></p>
                    <p><a class="nav-link" href="#about_me"><span><i class="fas fa-address-card"></i></span> About Me</a></p>
                    <p><a class="nav-link" href="#skills"><span><i class="fas fa-cogs"></i></span> Skills</a></p>
                    <p><a class="nav-link" href="#projects"><span><i class="fas fa-tasks"></i></span> Projects</a></p>
                </div>
                <div class="col-lg-3 col-md-4 col-12 contact_me ">
                    <h5 class = "mb-3"><b>Contact Me</b></h5>
                    <p>
                        <span><i class='fas fa-phone mr-2 mb-3'></i> 01681091173</span>
                    </p>
                    <p>
                        <span><i class='fas fa-envelope-square mr-2 mb-3'></i> rejwancse10@gmail.com</span>
                    </p>
                    <p>
                        <span><i class='fab fa-facebook mr-2 mb-3'></i><a href='https://www.facebook.com/Rejwan.cse/'>https://www.facebook.com/Rejwan.cse/</a></span>
                    </p>
                    <p>
                        <span><i class='fas fa-address-card mr-2 mb-3'></i>Mirpur-12, Dhaka</span>
                    </p>
                </div>
            </div>
            <div class="row justify-content-center" style = "background-color: #64b1b5">
                <p class = " mt-2">All Rights Reserved &copy; Md. Rejwan Ahmed</p>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->
</body>
</html>
