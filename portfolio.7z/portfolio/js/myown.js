
function myfunction()
{
    let details = document.getElementById("contact_me_details");
    details.innerHTML = "<p class = 'animate__animated animate__bounceInLeft'><span style = ''><i class='fas fa-phone mb-3 mr-2'></i> 01681091173</span> <br /><span><i class='fas fa-envelope-square mb-3 mr-2'></i> rejwancse10@gmail.com</span> <br /> <span><i class='fab fa-facebook mb-3 mr-2'></i><a style = 'color:black;'' href='https://www.facebook.com/Rejwan.cse/'>https://www.facebook.com/Rejwan.cse/</a></span></p>";
}

function htmlinfunction()
{
    document.getElementById('html').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 85%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>85%</div></div>";

}
function htmloutfunction()
{
    document.getElementById('html').innerHTML ="";
}
function cssinfunction()
{
    document.getElementById('css').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 75%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>75%</div></div>";

}
function cssoutfunction()
{
    document.getElementById('css').innerHTML ="";
}
function bootstrapinfunction()
{
    document.getElementById('bootstrap').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 80%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>80%</div></div>";

}
function bootstrapoutfunction()
{
    document.getElementById('bootstrap').innerHTML ="";
}
function jsinfunction()
{
    document.getElementById('js').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 70%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>70%</div></div>";

}
function jsoutfunction()
{
    document.getElementById('js').innerHTML ="";
}
function phpinfunction()
{
    document.getElementById('php').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 80%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>80%</div></div>";

}
function phpoutfunction()
{
    document.getElementById('php').innerHTML ="";
}
function laravelinfunction()
{
    document.getElementById('laravel').innerHTML = "<div class='animate__animated animate__fadeInLeft progress'><div class='progress-bar progress-bar-striped  bg-success' role='progressbar' style='width: 20%' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'>20%</div></div>";

}
function laraveloutfunction()
{
    document.getElementById('laravel').innerHTML ="";
}
